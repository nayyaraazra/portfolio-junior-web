<?php /* templates/footer.php */ ?>
</main>
<footer class='container py-3 text-center text-muted'>
  <small>&copy; <?= date('Y') ?> Pendaftaran Pelatihan</small>
</footer>

<!-- Urutan wajib: jQuery -> DataTables -> integrasi Bootstrap5 -> Bootstrap JS -> SweetAlert2 -> skrip sendiri -->
<script src='https://code.jquery.com/jquery-3.7.1.min.js'></script>
<script src='https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js'></script>
<script src='https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.26.25/dist/sweetalert2.all.min.js'></script>
<script src='assets/js/app.js'></script>
</body>
</html>
