
# Daftar Evaluasi Penggunaan Library Proyek

Dokumen ini berisi analisis kelayakan dan evaluasi library eksternal yang digunakan atau dipertimbangkan dalam proyek pendaftaran pelatihan.

## 1. Bootstrap (Versi 5.3.3)

- **Kesesuaian kebutuhan:** Sangat sesuai untuk membangun tata letak responsif dan komponen antarmuka seperti tombol, formulir, navigasi, dan modal.
- **Lisensi:** MIT License.
- **Pemeliharaan:** Memiliki dokumentasi resmi dan dukungan komunitas.
- **Popularitas dan komunitas:** Banyak digunakan dalam pengembangan antarmuka web, dengan dokumentasi dan contoh yang tersedia secara luas.
- **Kompatibilitas:** Mendukung browser modern. Bootstrap 5 tidak memerlukan jQuery.
- **Keamanan:** Gunakan versi yang sesuai kebutuhan proyek dan perbarui jika terdapat perbaikan keamanan yang relevan.
- **Ukuran dan performa:** Ukuran bergantung pada komponen CSS dan JavaScript yang digunakan. Fitur dropdown dan tooltip menggunakan Popper.
- **Kemudahan migrasi:** Sulit jika banyak halaman bergantung pada kelas dan komponen Bootstrap. Migrasi membutuhkan penyesuaian HTML dan CSS.

## 2. SweetAlert2 (Versi 11)

- **Kesesuaian kebutuhan:** Sesuai untuk menampilkan notifikasi keberhasilan, kegagalan, dan konfirmasi penghapusan data.
- **Lisensi:** MIT License.
- **Pemeliharaan:** Memiliki repositori dan dokumentasi resmi untuk pemeliharaan serta pelaporan masalah.
- **Popularitas dan komunitas:** Banyak digunakan untuk menampilkan dialog dan notifikasi interaktif.
- **Kompatibilitas:** Dapat digunakan dengan JavaScript biasa maupun berbagai framework frontend.
- **Keamanan:** Konten yang berasal dari pengguna harus ditangani dengan aman. Hindari memasukkan HTML yang tidak tepercaya ke dalam dialog.
- **Ukuran dan performa:** Menambah ukuran aset JavaScript yang dimuat aplikasi. Beban aktual bergantung pada cara library disertakan.
- **Kemudahan migrasi:** Relatif mudah jika pemanggilan notifikasi dipusatkan pada satu file JavaScript, seperti `public/assets/js/app.js`.

## 3. jQuery (Versi 3.7.1)

- **Kesesuaian kebutuhan:** Digunakan sebagai dependensi DataTables versi 1.13.8 dan membantu manipulasi DOM serta penanganan event.
- **Lisensi:** MIT License.
- **Pemeliharaan:** Memiliki dokumentasi resmi dan pembaruan untuk perbaikan yang diperlukan.
- **Popularitas dan komunitas:** Banyak digunakan pada aplikasi web yang menggunakan plugin berbasis jQuery.
- **Kompatibilitas:** Mendukung berbagai browser, dengan kompatibilitas aktual bergantung pada versi browser dan kebutuhan aplikasi.
- **Keamanan:** Gunakan versi yang sesuai dan hindari memasukkan konten HTML tidak tepercaya melalui manipulasi DOM.
- **Ukuran dan performa:** Menambah aset JavaScript yang perlu dimuat. Kebutuhan penggunaannya bergantung pada plugin yang digunakan.
- **Kemudahan migrasi:** Tingkat kesulitan bergantung pada jumlah kode yang menggunakan API jQuery. Penggunaan yang terbatas memudahkan penggantian di kemudian hari.

## 4. DataTables (Versi 1.13.8)

- **Kesesuaian kebutuhan:** Sesuai untuk menambahkan pencarian, pengurutan, dan pagination pada tabel pendaftar.
- **Lisensi:** MIT License.
- **Pemeliharaan:** Memiliki dokumentasi resmi dan dukungan pengembang melalui ekosistem DataTables.
- **Popularitas dan komunitas:** Banyak digunakan untuk membuat tabel interaktif pada aplikasi web.
- **Kompatibilitas:** DataTables versi 1.13.8 menggunakan jQuery. Integrasi tampilan harus disesuaikan dengan versi Bootstrap yang digunakan.
- **Keamanan:** Data dari server harus ditangani dengan aman sebelum ditampilkan. Perlindungan CSRF pada operasi penghapusan tetap harus dipertahankan.
- **Ukuran dan performa:** Menambah aset JavaScript dan CSS. Performa dipengaruhi oleh jumlah data, konfigurasi tabel, dan ekstensi yang digunakan.
- **Kemudahan migrasi:** Memerlukan penyesuaian konfigurasi dan kode jika diganti dengan library tabel lain.

## 5. Dompdf (Versi sesuai `composer.lock`)

- **Kesesuaian kebutuhan:** Sesuai untuk menghasilkan bukti pendaftaran dalam format PDF dari template HTML.
- **Lisensi:** LGPL. Ketentuan lisensi perlu diperiksa sesuai versi yang dipasang dan cara library didistribusikan atau dimodifikasi.
- **Pemeliharaan:** Informasi pemeliharaan dan kompatibilitas perlu mengacu pada dokumentasi serta repositori resmi Dompdf.
- **Popularitas dan komunitas:** Digunakan dalam ekosistem PHP untuk menghasilkan PDF dari HTML.
- **Kompatibilitas:** Bergantung pada versi Dompdf, versi PHP, dan ekstensi PHP yang dibutuhkan. Periksa persyaratan versi yang tercatat pada dependensi proyek.
- **Keamanan:** Batasi akses ke sumber eksternal dan gunakan konfigurasi keamanan yang sesuai. Jangan mengaktifkan akses file lokal atau sumber jarak jauh tanpa kebutuhan yang jelas.
- **Ukuran dan performa:** Memiliki dependensi Composer. Penggunaan memori dan waktu pemrosesan bergantung pada kompleksitas HTML, CSS, gambar, dan jumlah data.
- **Kemudahan migrasi:** Tingkat kesulitan sedang. Template HTML dan CSS mungkin memerlukan penyesuaian jika menggunakan library PDF lain.

## 6. FPDF (Alternatif)

- **Kesesuaian kebutuhan:** Merupakan alternatif untuk menghasilkan PDF secara terprogram. Layout dibuat menggunakan perintah dan koordinat, bukan langsung merender template HTML.
- **Lisensi:** Memiliki ketentuan lisensi tersendiri. Periksa lisensi versi yang akan digunakan sebelum distribusi.
- **Pemeliharaan:** Periksa situs dan repositori resmi untuk mengetahui status pemeliharaan versi yang dipilih.
- **Popularitas dan komunitas:** Memiliki dokumentasi serta contoh penggunaan untuk pembuatan PDF dengan PHP.
- **Kompatibilitas:** Periksa persyaratan PHP pada versi FPDF yang digunakan.
- **Keamanan:** Data yang dimasukkan ke dokumen tetap harus divalidasi dan ditangani dengan benar.
- **Ukuran dan performa:** Cocok untuk pembuatan dokumen dengan layout terkontrol. Beban pemrosesan bergantung pada isi dan struktur PDF.
- **Kemudahan migrasi:** Dapat sulit jika layout dibuat menggunakan banyak koordinat karena pemindahan ke library berbasis HTML memerlukan penyesuaian ulang.

## 7. Evaluasi Library Usang dan Alternatif

Library yang dinilai usang harus ditentukan berdasarkan versi yang benar-benar digunakan dalam proyek. Periksa status pemeliharaan, dukungan keamanan, dan kompatibilitasnya sebelum menentukan pengganti.

Alternatif dipilih berdasarkan fungsi, kompatibilitas dengan proyek, lisensi, dokumentasi, serta biaya migrasi. Catat nama library, versi yang diperiksa, alasan penggantian, dan alternatif yang dipilih.

## 8. Implikasi Lisensi untuk Aplikasi Komersial Tertutup

Lisensi setiap library harus diperiksa sebelum library didistribusikan bersama aplikasi. Lisensi MIT umumnya mengizinkan penggunaan komersial dengan tetap memenuhi ketentuan lisensinya. Lisensi LGPL dan GPL memiliki ketentuan berbeda terkait distribusi, modifikasi, dan penggabungan perangkat lunak.

Untuk Dompdf, periksa ketentuan LGPL dari versi yang terpasang. Untuk library berlisensi GPL, evaluasi cara integrasi dan distribusinya sebelum digunakan dalam aplikasi komersial tertutup. Jika diperlukan, mintalah penilaian hukum berdasarkan cara aplikasi didistribusikan.

## 9. Ringkasan Versi

| Library | Versi target atau acuan | Fungsi |
|---|---|---|
| Bootstrap | 5.3.3 | Antarmuka responsif |
| SweetAlert2 | 11 | Notifikasi dan konfirmasi |
| jQuery | 3.7.1 | Dependensi DataTables |
| DataTables | 1.13.8 | Pencarian, pengurutan, dan pagination |
| Dompdf | Sesuai `composer.lock` | Pembuatan bukti pendaftaran PDF |
| FPDF | Alternatif, jika diperlukan | Pembuatan PDF secara terprogram |

**Catatan:** Versi target pada tabel tidak otomatis membuktikan versi yang benar-benar terpasang. Cocokkan versi library dengan konfigurasi proyek, file aset, dan `composer.lock` sebelum menyatakan hasil evaluasi selesai.
