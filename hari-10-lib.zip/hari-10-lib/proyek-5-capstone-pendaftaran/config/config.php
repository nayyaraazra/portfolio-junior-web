<?php
declare(strict_types=1);

// Konfigurasi lokal. Jangan commit file ini ke repositori.
return [
    'host' => 'localhost',
    'nama_db' => 'db_pelatihan',
    'user' => 'root',
    'sandi' => 'maululus2027',
    'debug' => true,
];
